﻿namespace ClassLibraryTest
{
    public class Class1
    {

    }
}
