﻿namespace StudentSystem;

partial class Form1
{
    /// <summary>
    ///  Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    ///  Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null))
        {
            components.Dispose();
        }

        base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    ///  Required method for Designer support - do not modify
    ///  the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
        addForm = new GroupBox();
        textBox4 = new TextBox();
        textBox3 = new TextBox();
        textBox2 = new TextBox();
        textBox1 = new TextBox();
        label4 = new Label();
        label3 = new Label();
        label2 = new Label();
        label1 = new Label();
        label5 = new Label();
        textBox5 = new TextBox();
        label6 = new Label();
        textBox6 = new TextBox();
        button1 = new Button();
        button2 = new Button();
        button3 = new Button();
        button4 = new Button();
        button5 = new Button();
        button6 = new Button();
        listBox1 = new ListBox();
        personFrom = new GroupBox();
        label7 = new Label();
        textBox7 = new TextBox();
        button7 = new Button();
        groupBox1 = new GroupBox();
        button8 = new Button();
        textBox8 = new TextBox();
        label8 = new Label();
        button9 = new Button();
        textBox9 = new TextBox();
        button10 = new Button();
        groupBox2 = new GroupBox();
        button11 = new Button();
        button12 = new Button();
        textBox11 = new TextBox();
        label9 = new Label();
        button13 = new Button();
        addForm.SuspendLayout();
        personFrom.SuspendLayout();
        groupBox1.SuspendLayout();
        groupBox2.SuspendLayout();
        SuspendLayout();
        // 
        // addForm
        // 
        addForm.Controls.Add(button3);
        addForm.Controls.Add(button2);
        addForm.Controls.Add(button1);
        addForm.Controls.Add(textBox6);
        addForm.Controls.Add(label6);
        addForm.Controls.Add(textBox5);
        addForm.Controls.Add(label5);
        addForm.Controls.Add(textBox4);
        addForm.Controls.Add(textBox3);
        addForm.Controls.Add(textBox2);
        addForm.Controls.Add(textBox1);
        addForm.Controls.Add(label4);
        addForm.Controls.Add(label3);
        addForm.Controls.Add(label2);
        addForm.Controls.Add(label1);
        addForm.Location = new Point(12, 12);
        addForm.Name = "addForm";
        addForm.Size = new Size(991, 266);
        addForm.TabIndex = 0;
        addForm.TabStop = false;
        addForm.Text = "Add Form";
        // 
        // textBox4
        // 
        textBox4.Font = new Font("Segoe UI", 12F);
        textBox4.Location = new Point(185, 159);
        textBox4.Name = "textBox4";
        textBox4.Size = new Size(148, 34);
        textBox4.TabIndex = 7;
        // 
        // textBox3
        // 
        textBox3.Font = new Font("Segoe UI", 12F);
        textBox3.Location = new Point(185, 119);
        textBox3.Name = "textBox3";
        textBox3.Size = new Size(148, 34);
        textBox3.TabIndex = 6;
        // 
        // textBox2
        // 
        textBox2.Font = new Font("Segoe UI", 12F);
        textBox2.Location = new Point(185, 79);
        textBox2.Name = "textBox2";
        textBox2.Size = new Size(148, 34);
        textBox2.TabIndex = 5;
        // 
        // textBox1
        // 
        textBox1.Font = new Font("Segoe UI", 12F);
        textBox1.Location = new Point(185, 40);
        textBox1.Name = "textBox1";
        textBox1.Size = new Size(148, 34);
        textBox1.TabIndex = 4;
        // 
        // label4
        // 
        label4.AutoSize = true;
        label4.Font = new Font("Segoe UI", 12F);
        label4.Location = new Point(20, 157);
        label4.Name = "label4";
        label4.Size = new Size(136, 28);
        label4.TabIndex = 3;
        label4.Text = "Year at school:";
        // 
        // label3
        // 
        label3.AutoSize = true;
        label3.Font = new Font("Segoe UI", 12F);
        label3.Location = new Point(20, 119);
        label3.Name = "label3";
        label3.Size = new Size(51, 28);
        label3.TabIndex = 2;
        label3.Text = "Age:";
        // 
        // label2
        // 
        label2.AutoSize = true;
        label2.Font = new Font("Segoe UI", 12F);
        label2.Location = new Point(20, 82);
        label2.Name = "label2";
        label2.Size = new Size(68, 28);
        label2.TabIndex = 1;
        label2.Text = "Name:";
        // 
        // label1
        // 
        label1.AutoSize = true;
        label1.Font = new Font("Segoe UI", 12F);
        label1.Location = new Point(20, 43);
        label1.Name = "label1";
        label1.Size = new Size(54, 28);
        label1.TabIndex = 0;
        label1.Text = "PCN:";
        // 
        // label5
        // 
        label5.AutoSize = true;
        label5.Font = new Font("Segoe UI", 12F);
        label5.Location = new Point(402, 159);
        label5.Name = "label5";
        label5.Size = new Size(51, 28);
        label5.TabIndex = 8;
        label5.Text = "EC's:";
        // 
        // textBox5
        // 
        textBox5.Font = new Font("Segoe UI", 12F);
        textBox5.Location = new Point(490, 154);
        textBox5.Name = "textBox5";
        textBox5.Size = new Size(148, 34);
        textBox5.TabIndex = 9;
        // 
        // label6
        // 
        label6.AutoSize = true;
        label6.Font = new Font("Segoe UI", 12F);
        label6.Location = new Point(722, 157);
        label6.Name = "label6";
        label6.Size = new Size(69, 28);
        label6.TabIndex = 10;
        label6.Text = "Salary:";
        // 
        // textBox6
        // 
        textBox6.Font = new Font("Segoe UI", 12F);
        textBox6.Location = new Point(808, 154);
        textBox6.Name = "textBox6";
        textBox6.Size = new Size(148, 34);
        textBox6.TabIndex = 11;
        // 
        // button1
        // 
        button1.Font = new Font("Segoe UI", 12F);
        button1.Location = new Point(51, 209);
        button1.Name = "button1";
        button1.Size = new Size(272, 40);
        button1.TabIndex = 12;
        button1.Text = "New person";
        button1.UseVisualStyleBackColor = true;
        // 
        // button2
        // 
        button2.Font = new Font("Segoe UI", 12F);
        button2.Location = new Point(383, 209);
        button2.Name = "button2";
        button2.Size = new Size(267, 40);
        button2.TabIndex = 13;
        button2.Text = "New student";
        button2.UseVisualStyleBackColor = true;
        // 
        // button3
        // 
        button3.Font = new Font("Segoe UI", 12F);
        button3.Location = new Point(722, 209);
        button3.Name = "button3";
        button3.Size = new Size(239, 40);
        button3.TabIndex = 14;
        button3.Text = "New teacher";
        button3.UseVisualStyleBackColor = true;
        // 
        // button4
        // 
        button4.Font = new Font("Segoe UI", 12F);
        button4.Location = new Point(63, 294);
        button4.Name = "button4";
        button4.Size = new Size(272, 40);
        button4.TabIndex = 15;
        button4.Text = "Show all persons";
        button4.UseVisualStyleBackColor = true;
        // 
        // button5
        // 
        button5.Font = new Font("Segoe UI", 12F);
        button5.Location = new Point(395, 294);
        button5.Name = "button5";
        button5.Size = new Size(267, 40);
        button5.TabIndex = 16;
        button5.Text = "Show all students";
        button5.UseVisualStyleBackColor = true;
        // 
        // button6
        // 
        button6.Font = new Font("Segoe UI", 12F);
        button6.Location = new Point(734, 294);
        button6.Name = "button6";
        button6.Size = new Size(239, 40);
        button6.TabIndex = 17;
        button6.Text = "Show all teachers";
        button6.UseVisualStyleBackColor = true;
        // 
        // listBox1
        // 
        listBox1.Font = new Font("Segoe UI", 12F);
        listBox1.FormattingEnabled = true;
        listBox1.ItemHeight = 28;
        listBox1.Location = new Point(32, 364);
        listBox1.Name = "listBox1";
        listBox1.Size = new Size(941, 312);
        listBox1.TabIndex = 18;
        // 
        // personFrom
        // 
        personFrom.Controls.Add(button7);
        personFrom.Controls.Add(textBox7);
        personFrom.Controls.Add(label7);
        personFrom.Font = new Font("Segoe UI", 12F);
        personFrom.Location = new Point(32, 708);
        personFrom.Name = "personFrom";
        personFrom.Size = new Size(313, 244);
        personFrom.TabIndex = 19;
        personFrom.TabStop = false;
        personFrom.Text = "Person from";
        // 
        // label7
        // 
        label7.AutoSize = true;
        label7.Font = new Font("Segoe UI", 12F);
        label7.Location = new Point(14, 42);
        label7.Name = "label7";
        label7.Size = new Size(54, 28);
        label7.TabIndex = 15;
        label7.Text = "PCN:";
        // 
        // textBox7
        // 
        textBox7.Font = new Font("Segoe UI", 12F);
        textBox7.Location = new Point(103, 36);
        textBox7.Name = "textBox7";
        textBox7.Size = new Size(184, 34);
        textBox7.TabIndex = 15;
        // 
        // button7
        // 
        button7.Font = new Font("Segoe UI", 12F);
        button7.Location = new Point(14, 93);
        button7.Name = "button7";
        button7.Size = new Size(273, 40);
        button7.TabIndex = 15;
        button7.Text = "Show info";
        button7.UseVisualStyleBackColor = true;
        // 
        // groupBox1
        // 
        groupBox1.Controls.Add(textBox9);
        groupBox1.Controls.Add(button10);
        groupBox1.Controls.Add(button9);
        groupBox1.Controls.Add(button8);
        groupBox1.Controls.Add(textBox8);
        groupBox1.Controls.Add(label8);
        groupBox1.Font = new Font("Segoe UI", 12F);
        groupBox1.Location = new Point(378, 708);
        groupBox1.Name = "groupBox1";
        groupBox1.Size = new Size(313, 244);
        groupBox1.TabIndex = 20;
        groupBox1.TabStop = false;
        groupBox1.Text = "Student from";
        // 
        // button8
        // 
        button8.Font = new Font("Segoe UI", 12F);
        button8.Location = new Point(14, 93);
        button8.Name = "button8";
        button8.Size = new Size(289, 40);
        button8.TabIndex = 15;
        button8.Text = "Show info";
        button8.UseVisualStyleBackColor = true;
        // 
        // textBox8
        // 
        textBox8.Font = new Font("Segoe UI", 12F);
        textBox8.Location = new Point(103, 36);
        textBox8.Name = "textBox8";
        textBox8.Size = new Size(200, 34);
        textBox8.TabIndex = 15;
        // 
        // label8
        // 
        label8.AutoSize = true;
        label8.Font = new Font("Segoe UI", 12F);
        label8.Location = new Point(14, 42);
        label8.Name = "label8";
        label8.Size = new Size(54, 28);
        label8.TabIndex = 15;
        label8.Text = "PCN:";
        // 
        // button9
        // 
        button9.Font = new Font("Segoe UI", 12F);
        button9.Location = new Point(14, 139);
        button9.Name = "button9";
        button9.Size = new Size(289, 40);
        button9.TabIndex = 16;
        button9.Text = "Start new schoolyear";
        button9.UseVisualStyleBackColor = true;
        // 
        // textBox9
        // 
        textBox9.Font = new Font("Segoe UI", 12F);
        textBox9.Location = new Point(19, 195);
        textBox9.Name = "textBox9";
        textBox9.Size = new Size(110, 34);
        textBox9.TabIndex = 15;
        // 
        // button10
        // 
        button10.Font = new Font("Segoe UI", 12F);
        button10.Location = new Point(148, 189);
        button10.Name = "button10";
        button10.Size = new Size(155, 40);
        button10.TabIndex = 16;
        button10.Text = "Add ECs";
        button10.UseVisualStyleBackColor = true;
        // 
        // groupBox2
        // 
        groupBox2.Controls.Add(button13);
        groupBox2.Controls.Add(button11);
        groupBox2.Controls.Add(button12);
        groupBox2.Controls.Add(textBox11);
        groupBox2.Controls.Add(label9);
        groupBox2.Font = new Font("Segoe UI", 12F);
        groupBox2.Location = new Point(734, 708);
        groupBox2.Name = "groupBox2";
        groupBox2.Size = new Size(269, 244);
        groupBox2.TabIndex = 21;
        groupBox2.TabStop = false;
        groupBox2.Text = "Teacher from";
        // 
        // button11
        // 
        button11.Font = new Font("Segoe UI", 12F);
        button11.Location = new Point(19, 139);
        button11.Name = "button11";
        button11.Size = new Size(225, 40);
        button11.TabIndex = 16;
        button11.Text = "Start new schoolyear";
        button11.UseVisualStyleBackColor = true;
        // 
        // button12
        // 
        button12.Font = new Font("Segoe UI", 12F);
        button12.Location = new Point(19, 93);
        button12.Name = "button12";
        button12.Size = new Size(225, 40);
        button12.TabIndex = 15;
        button12.Text = "Show info";
        button12.UseVisualStyleBackColor = true;
        // 
        // textBox11
        // 
        textBox11.Font = new Font("Segoe UI", 12F);
        textBox11.Location = new Point(103, 36);
        textBox11.Name = "textBox11";
        textBox11.Size = new Size(200, 34);
        textBox11.TabIndex = 15;
        // 
        // label9
        // 
        label9.AutoSize = true;
        label9.Font = new Font("Segoe UI", 12F);
        label9.Location = new Point(14, 42);
        label9.Name = "label9";
        label9.Size = new Size(54, 28);
        label9.TabIndex = 15;
        label9.Text = "PCN:";
        // 
        // button13
        // 
        button13.Font = new Font("Segoe UI", 12F);
        button13.Location = new Point(19, 185);
        button13.Name = "button13";
        button13.Size = new Size(225, 40);
        button13.TabIndex = 17;
        button13.Text = "Promote";
        button13.UseVisualStyleBackColor = true;
        // 
        // Form1
        // 
        AutoScaleDimensions = new SizeF(8F, 20F);
        AutoScaleMode = AutoScaleMode.Font;
        ClientSize = new Size(1015, 977);
        Controls.Add(groupBox2);
        Controls.Add(groupBox1);
        Controls.Add(personFrom);
        Controls.Add(listBox1);
        Controls.Add(button6);
        Controls.Add(button5);
        Controls.Add(button4);
        Controls.Add(addForm);
        Name = "Form1";
        Text = "Form1";
        addForm.ResumeLayout(false);
        addForm.PerformLayout();
        personFrom.ResumeLayout(false);
        personFrom.PerformLayout();
        groupBox1.ResumeLayout(false);
        groupBox1.PerformLayout();
        groupBox2.ResumeLayout(false);
        groupBox2.PerformLayout();
        ResumeLayout(false);
    }

    #endregion

    private GroupBox addForm;
    private Label label4;
    private Label label3;
    private Label label2;
    private Label label1;
    private TextBox textBox1;
    private TextBox textBox4;
    private TextBox textBox3;
    private TextBox textBox2;
    private Label label6;
    private TextBox textBox5;
    private Label label5;
    private TextBox textBox6;
    private Button button3;
    private Button button2;
    private Button button1;
    private Button button4;
    private Button button5;
    private Button button6;
    private ListBox listBox1;
    private GroupBox personFrom;
    private TextBox textBox7;
    private Label label7;
    private Button button7;
    private GroupBox groupBox1;
    private Button button9;
    private Button button8;
    private TextBox textBox8;
    private Label label8;
    private TextBox textBox9;
    private Button button10;
    private GroupBox groupBox2;
    private Button button13;
    private Button button11;
    private Button button12;
    private TextBox textBox11;
    private Label label9;
}