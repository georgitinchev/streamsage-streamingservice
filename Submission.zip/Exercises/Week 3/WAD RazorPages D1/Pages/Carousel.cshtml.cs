using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace RazorPages.Pages
{
    public class CarouselModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
