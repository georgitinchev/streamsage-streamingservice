﻿namespace EmployeesProject.Models
{
	public class UserRole
	{
	}
}
