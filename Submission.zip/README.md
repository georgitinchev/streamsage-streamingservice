Please ensure that your display's DPI scaling is <= 125% before attempting use (For OOD only)

Link to Luna:
https://i524441.luna.fhict.nl/

Credentials that can be used:
In order -> Username, Email, Password, FirstName, LastName

('john_doe', 'john.doe@example.com', 'password123', 'John', 'Doe'),
('jane_smith', 'jane.smith@example.com', 'password456', 'Jane', 'Smith'),
('alice_johnson', 'alice.johnson@example.com', 'password789', 'Alice', 'Johnson'),
('bob_brown', 'bob.brown@example.com', 'passwordabc', 'Bob', 'Brown'),
('emily_davis', 'emily.davis@example.com', 'passworddef', 'Emily', 'Davis');
('georgitin', 'georgi.tinchev.124@gmail.com, 'e9999619', 'Georgi', 'Tinchev');

Link to Repo:
https://git.fhict.nl/I524441/individual-project-sem2