using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace StreamSageWAD.Pages
{
    public class LeaderboardsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
